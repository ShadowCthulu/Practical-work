﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Practika_5
{
    public partial class Form1 : Form
    {
        int countButton = 1;
        Button b;
        int countLabel = 1;
        Label a;
        int countTextBox = 1;
        TextBox c;

        public Form1()
        {
            InitializeComponent();

            b = new Button();
            b.Top = 0;
            b.Left = 0;
            b.Text = "Button-" + countButton.ToString();
            b.Click += b_Click;
            this.Controls.Add(b);

            a = new Label();
            a.Top = 0;
            a.Left = 0;
            a.Text = "Label-" + countLabel.ToString();
            a.Click += b_Click;
            this.Controls.Add(a);

            c = new TextBox();
            c.Top = 0;
            c.Left = 0;
            c.Text = "TextBox-" + countTextBox.ToString();
            c.Click += b_Click;
            this.Controls.Add(c);


        }
        void b_Click(object sender, EventArgs e)
        {
            int top = b.Bottom;
            int left = b.Left;
            b = new Button();
            b.Top = top;
            b.Left = left;
            b.Text = "Button-" + (++countButton).ToString();
            b.Click += b_Click;
            this.Controls.Add(b);

            int down = b.Bottom;
            int right = b.Right;
            a = new Label();
            a.Top = top;
            a.Left = left;
            a.Text = "Label-" + (++countLabel).ToString();
            a.Click += b_Click;
            this.Controls.Add(a);

            int Top = b.Bottom;
            int Right = b.Left;
            c = new TextBox();
            c.Top = top;
            c.Left = left;
            c.Text = "TextBox-" + (++countTextBox).ToString();
            c.Click += b_Click;
            this.Controls.Add(c);
        }
    }
}
    

